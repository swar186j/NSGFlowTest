import logging
import os
import subprocess
import sys


# Function to install a package if it's not already installed
def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])


# List of required packages
required_packages = ["azure-functions", "azure-storage-blob", "azure-eventhub"]
# Install required packages if not already installed
for package in required_packages:
    try:
        __import__(package)
    except ImportError:
        logging.info(f"Installing package: {package}")
        install(package)
from azure.storage.blob import BlobServiceClient
from azure.eventhub import EventHubProducerClient, EventData
import azure.functions as func
from datetime import datetime, timezone


def main(mytimer: func.TimerRequest) -> None:
    logging.info("Python timer trigger function started")
    # Retrieve environment variables for connection strings and container names
    source_connection_string = os.getenv("NsgSourceConnectionString")
    event_hub_connection_string = os.getenv("EventHubConnectionString")
    # Validate connection strings (optional)
    if not source_connection_string or not event_hub_connection_string:
        logging.error("Missing required environment variables for connection strings")
        return
    try:
        # Initialize BlobServiceClient for the source storage account
        source_blob_service_client = BlobServiceClient.from_connection_string(
            source_connection_string
        )
        # Initialize EventHubProducerClient for the Event Hub
        event_hub_client = EventHubProducerClient.from_connection_string(
            event_hub_connection_string
        )
        # Get the current hour to process only current hour logs
        current_hour = datetime.now(timezone.utc).replace(
            minute=0, second=0, microsecond=0
        )
        # Retrieve the source container client
        source_container_name = f"insights-logs-networksecuritygroupflowevent/{current_hour.strftime('%Y/%m/%d')}/"
        source_container_client = source_blob_service_client.get_container_client(
            source_container_name
        )
        # List blobs in the source container
        blob_list = source_container_client.list_blobs()
        # Process each blob
        for blob in blob_list:
            logging.info(f"Processing blob: {blob.name}")
            # Get source blob client
            source_blob_client = source_container_client.get_blob_client(blob.name)
            # Download blob content
            blob_data = source_blob_client.download_blob().readall()
            # Send blob data to Event Hub
            event_data_batch = event_hub_client.create_batch()
            event_data_batch.add(EventData(blob_data))
            event_hub_client.send_batch(event_data_batch)
            logging.info(f"Sent blob: {blob.name} to Event Hub")
    except Exception as e:
        logging.error(f"Error processing blob: {e}")
    logging.info("Python timer trigger function completed")
