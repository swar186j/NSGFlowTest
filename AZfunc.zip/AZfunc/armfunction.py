import logging
import os
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
import azure.functions as func
from datetime import datetime, timedelta, timezone


def main(mytimer: func.TimerRequest) -> None:
    logging.info("Python timer trigger function started")
    # Retrieve environment variables for connection strings and container names
    source_connection_string = os.getenv("NsgSourceConnectionString")
    destination_connection_string = os.getenv("DestinationStorageConnectionString")
    # Validate connection strings (optional)
    if not source_connection_string or not destination_connection_string:
        logging.error("Missing required environment variables for connection strings")
        return
    try:
        # Initialize BlobServiceClient for both source and destination storage accounts
        source_blob_service_client = BlobServiceClient.from_connection_string(
            source_connection_string
        )
        destination_blob_service_client = BlobServiceClient.from_connection_string(
            destination_connection_string
        )
        # Get the current hour to process only current hour logs
        current_hour = datetime.now(timezone.utc).replace(
            minute=0, second=0, microsecond=0
        )
        # Retrieve the source container client
        source_container_name = f"insights-logs-networksecuritygroupflowevent/{current_hour.strftime('%Y/%m/%d')}/"
        source_container_client = source_blob_service_client.get_container_client(
            source_container_name
        )
        # Retrieve the destination container client
        destination_container_name = f"insights-logs-networksecuritygroupflowevent/{current_hour.strftime('%Y/%m/%d')}/"
        destination_container_client = (
            destination_blob_service_client.get_container_client(
                destination_container_name
            )
        )
        # List blobs in the source container
        blob_list = source_container_client.list_blobs()
        # Process each blob
        for blob in blob_list:
            logging.info(f"Processing blob: {blob.name}")
            # Get source blob client
            source_blob_client = source_container_client.get_blob_client(blob.name)
            # Download blob content
            blob_data = source_blob_client.download_blob().readall()
            # Get destination blob client
            destination_blob_client = destination_container_client.get_blob_client(
                blob.name
            )
            # Upload blob content to the destination container
            destination_blob_client.upload_blob(blob_data, overwrite=True)
            logging.info(
                f"Uploaded blob: {blob.name} to container: {destination_container_name}"
            )
    except Exception as e:
        logging.error(f"Error processing blob: {e}")
    logging.info("Python timer trigger function completed")
